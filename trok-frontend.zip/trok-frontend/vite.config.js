import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// Le proxy envoie /api vers Express (port 3000) : pas de souci de CORS ni de cookies de session
export default defineConfig({
  plugins: [vue()],
  server: { port: 5173, proxy: { '/api': 'http://localhost:3000' } }
})
