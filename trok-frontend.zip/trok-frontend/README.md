# TROK — Frontend Vue 3

## Installation
```bash
npm install
npm run dev      # http://localhost:5173
```
Le backend Express doit tourner sur http://localhost:3000 (le proxy Vite redirige `/api`).

## Structure
- `src/views/`       pages (Home, Courses, Auth, Publish, Dashboard, Messages)
- `src/components/`  composants réutilisables (NavBar, CourseCard, CourseModal)
- `src/store.js`     état global (utilisateur connecté, toast)
- `src/api.js`       client HTTP (fetch + cookies de session)
- `src/router.js`    routes + garde d'authentification

## API attendue (JSON, session par cookie)
| Méthode | Route | Rôle |
|---|---|---|
| POST | /api/auth/register | inscription (+50 TC) → `{user}` |
| POST | /api/auth/login | connexion → `{user}` |
| POST | /api/auth/logout | déconnexion |
| GET / PUT | /api/auth/me | session / modifier profil → `{user}` |
| GET / POST | /api/courses | liste `{courses}` (avec `teacher`) / création |
| GET | /api/courses/mine | mes cours |
| GET / PUT / DELETE | /api/courses/:id | détail `{course}` / modifier / supprimer (propriétaire) |
| POST | /api/courses/:id/buy | achat (transaction) → `{balance}` |
| GET | /api/transactions | `{transactions}` (avec `course`, `buyerId`, `amount`, `createdAt`) |
| GET | /api/messages/conversations | `{conversations:[{user,lastMessage}]}` |
| GET | /api/messages/:userId | `{messages}` (`senderId`, `content`) |
| POST | /api/messages | `{toUserId, content}` → `{message}` |

Champs d'un cours : `title, category, description, level, price, inPerson, remote, emoji, teacherId`.
Champs d'un user : `id, firstName, lastName, email, age, interests, availability, balance`.
