<script setup>
import NavBar from './components/NavBar.vue'
import { store } from './store'
</script>

<template>
  <NavBar />
  <main><router-view /></main>
  <footer>
    <div class="container foot">
      <strong class="logo-w">TR<span>●</span>K</strong>
      <span>© 2026 TROK — Fait par des étudiants, pour des étudiants</span>
    </div>
  </footer>
  <div class="toast" :class="{ show: store.toast }" role="status">{{ store.toast }}</div>
</template>
