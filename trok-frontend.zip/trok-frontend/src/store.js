import { reactive } from 'vue'
import { api } from './api'

// État global partagé (utilisateur connecté + toast), sans librairie externe
export const store = reactive({
  user: null,
  toast: '',
  _t: null,
  showToast(msg) {
    this.toast = msg
    clearTimeout(this._t)
    this._t = setTimeout(() => (this.toast = ''), 3500)
  },
  async fetchMe() {
    try { this.user = (await api.get('/auth/me')).user } catch { this.user = null }
  },
  async login(email, password) { this.user = (await api.post('/auth/login', { email, password })).user },
  async register(payload) { this.user = (await api.post('/auth/register', payload)).user },
  async logout() { await api.post('/auth/logout'); this.user = null }
})
