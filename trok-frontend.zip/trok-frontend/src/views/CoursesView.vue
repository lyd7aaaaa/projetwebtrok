<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { api } from '../api'
import { store } from '../store'
import CourseCard from '../components/CourseCard.vue'
import CourseModal from '../components/CourseModal.vue'

const router = useRouter()
const courses = ref([])
const loading = ref(true)
const error = ref('')
const search = ref('')
const category = ref('all')
const inPersonOnly = ref(false)
const sort = ref('recent')
const selected = ref(null)
const categories = ['Code', 'Musique', 'Art', 'Langues', 'Maths', 'Sport', 'Photo', 'Cuisine']

async function load() {
  try { courses.value = (await api.get('/courses')).courses }   // READ
  catch (e) { error.value = e.message }
  finally { loading.value = false }
}
onMounted(load)

// Propriété calculée : recherche + filtres + tri combinés
const filtered = computed(() => {
  const q = search.value.toLowerCase()
  let list = courses.value.filter(c =>
    (category.value === 'all' || c.category === category.value) &&
    (!inPersonOnly.value || c.inPerson) &&
    (!q || (c.title + c.description + (c.teacher?.firstName || '')).toLowerCase().includes(q)))
  if (sort.value === 'asc') list = [...list].sort((a, b) => a.price - b.price)
  if (sort.value === 'desc') list = [...list].sort((a, b) => b.price - a.price)
  return list
})

async function buy(c) {
  if (!store.user) return router.push('/connexion')
  try {
    const r = await api.post(`/courses/${c.id}/buy`)
    store.user.balance = r.balance
    store.showToast(`Cours acheté ! −${c.price} TC`)
    selected.value = null
  } catch (e) { store.showToast('⚠️ ' + e.message) }
}
async function remove(c) {
  if (!confirm('Supprimer ce cours ?')) return
  try {
    await api.del(`/courses/${c.id}`)                            // DELETE
    courses.value = courses.value.filter(x => x.id !== c.id)
    selected.value = null
    store.showToast('Cours supprimé')
  } catch (e) { store.showToast('⚠️ ' + e.message) }
}
const contact = (c) => router.push({ path: '/messages', query: { to: c.teacherId } })
</script>

<template>
  <div class="container section">
    <div class="row-between">
      <div><h1>Cours disponibles</h1><p class="muted">{{ filtered.length }} cours trouvés</p></div>
      <router-link to="/publier" class="btn btn-green">+ Proposer mon cours</router-link>
    </div>

    <div class="toolbar">
      <input class="form-input" type="search" v-model="search" placeholder="Rechercher un cours, une compétence, un enseignant…">
      <select class="form-input" v-model="sort" aria-label="Trier">
        <option value="recent">Plus récents</option>
        <option value="asc">Prix croissant</option>
        <option value="desc">Prix décroissant</option>
      </select>
    </div>
    <div class="pills">
      <button class="pill" :class="{ active: category === 'all' }" @click="category = 'all'">Tous</button>
      <button v-for="c in categories" :key="c" class="pill" :class="{ active: category === c }" @click="category = c">{{ c }}</button>
      <button class="pill" :class="{ active: inPersonOnly }" @click="inPersonOnly = !inPersonOnly">📍 Présentiel</button>
    </div>

    <p v-if="loading" class="muted">Chargement…</p>
    <p v-else-if="error" class="error">{{ error }}</p>
    <p v-else-if="!filtered.length" class="muted">Aucun cours ne correspond à ta recherche.</p>
    <div v-else class="grid-3">
      <CourseCard v-for="c in filtered" :key="c.id" :course="c" @open="selected = $event" />
    </div>

    <CourseModal v-if="selected" :course="selected" @close="selected = null" @buy="buy" @delete="remove"
                 @edit="router.push('/publier/' + $event.id)" @contact="contact" />
  </div>
</template>
