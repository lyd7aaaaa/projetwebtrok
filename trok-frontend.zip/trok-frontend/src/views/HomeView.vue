<script setup>
const steps = [
  { icon: '👤', title: 'Crée ton compte', text: 'Inscris-toi avec ton mail étudiant et reçois 50 TC de bienvenue.' },
  { icon: '📚', title: 'Propose ou achète', text: 'Publie ton expertise avec un prix en TC, ou achète un cours du catalogue.' },
  { icon: '💬', title: 'Échange et apprends', text: 'Contacte l’enseignant par la messagerie et organisez votre session.' }
]
</script>

<template>
  <section class="hero container">
    <div>
      <h1>Échange ton <em>savoir</em> contre des coins</h1>
      <p class="muted lead">TROK est la plateforme d’échange de connaissances entre étudiants. Enseigne ce que tu maîtrises, apprends ce dont tu as besoin, sans payer en euros.</p>
      <div class="actions">
        <router-link to="/connexion" class="btn btn-green btn-lg">Rejoindre TROK</router-link>
        <router-link to="/cours" class="btn btn-outline btn-lg">Voir les cours</router-link>
      </div>
    </div>
  </section>
  <section class="container section">
    <h2>Comment ça marche</h2>
    <div class="grid-3">
      <!-- v-for : une carte par étape -->
      <article class="card pad" v-for="s in steps" :key="s.title">
        <div class="step-icon">{{ s.icon }}</div>
        <h3>{{ s.title }}</h3>
        <p class="muted">{{ s.text }}</p>
      </article>
    </div>
  </section>
</template>
