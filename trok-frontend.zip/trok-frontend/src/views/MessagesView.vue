<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { useRoute } from 'vue-router'
import { api } from '../api'
import { store } from '../store'

const route = useRoute()
const conversations = ref([])   // [{ user: {id, firstName, lastName}, lastMessage }]
const current = ref(null)       // utilisateur avec qui on discute
const messages = ref([])
const text = ref('')
const box = ref(null)

async function loadConversations() {
  conversations.value = (await api.get('/messages/conversations')).conversations
}
async function open(user) {
  current.value = user
  messages.value = (await api.get('/messages/' + user.id)).messages
  await nextTick()
  if (box.value) box.value.scrollTop = box.value.scrollHeight
}
async function send() {
  if (!text.value.trim() || !current.value) return
  try {
    const m = (await api.post('/messages', { toUserId: current.value.id, content: text.value })).message
    messages.value.push(m)
    text.value = ''
    await nextTick()
    box.value.scrollTop = box.value.scrollHeight
    loadConversations()
  } catch (e) { store.showToast('⚠️ ' + e.message) }
}

onMounted(async () => {
  await loadConversations()
  // Arrivée depuis un cours ("Contacter") : ?to=<id enseignant>
  const to = Number(route.query.to)
  if (to) {
    const found = conversations.value.find(c => c.user.id === to)
    await open(found ? found.user : { id: to, firstName: 'Enseignant', lastName: '' })
  }
})
</script>

<template>
  <div class="container section chat">
    <aside class="card conv-list">
      <h2>Messages</h2>
      <p v-if="!conversations.length" class="muted small pad">Aucune conversation pour l’instant.</p>
      <button v-for="c in conversations" :key="c.user.id" class="conv" :class="{ active: current?.id === c.user.id }" @click="open(c.user)">
        <strong>{{ c.user.firstName }} {{ c.user.lastName }}</strong>
        <span class="muted small">{{ c.lastMessage }}</span>
      </button>
    </aside>

    <section class="card chat-area">
      <p v-if="!current" class="muted pad">Choisis une conversation.</p>
      <template v-else>
        <header class="chat-head"><strong>{{ current.firstName }} {{ current.lastName }}</strong></header>
        <div class="msgs" ref="box">
          <!-- Classe dynamique : bulle verte si le message vient de moi -->
          <div v-for="m in messages" :key="m.id" class="bubble" :class="m.senderId === store.user.id ? 'out' : 'in'">{{ m.content }}</div>
        </div>
        <form class="chat-input" @submit.prevent="send">
          <input class="form-input" v-model="text" placeholder="Écris un message…" maxlength="1000">
          <button class="btn btn-green">Envoyer</button>
        </form>
      </template>
    </section>
  </div>
</template>
