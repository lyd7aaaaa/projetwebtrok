<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router'
import { store } from '../store'

const router = useRouter()
const mode = ref('register')
const errors = ref([])
const interestsList = ['Code', 'Musique', 'Art', 'Langues', 'Maths', 'Sport', 'Photo', 'Cuisine', 'Théâtre']
const form = reactive({ firstName: '', lastName: '', email: '', age: '', password: '', interests: [], availability: '' })

// Validation côté client (le serveur valide aussi : ne jamais faire confiance au client)
function validate() {
  const e = []
  if (mode.value === 'register') {
    if (!form.firstName.trim() || !form.lastName.trim()) e.push('Prénom et nom obligatoires.')
    if (!(form.age >= 16 && form.age <= 35)) e.push('Âge entre 16 et 35 ans.')
    if (form.password.length < 8) e.push('Mot de passe : 8 caractères minimum.')
  }
  if (!/^\S+@\S+\.\S+$/.test(form.email)) e.push('Adresse mail invalide.')
  if (!form.password) e.push('Mot de passe obligatoire.')
  return e
}
function toggle(i) {
  const k = form.interests.indexOf(i)
  k === -1 ? form.interests.push(i) : form.interests.splice(k, 1)
}
async function submit() {
  errors.value = validate()
  if (errors.value.length) return
  try {
    if (mode.value === 'register') {
      await store.register({ ...form, interests: form.interests.join(',') })
      store.showToast('🎉 Compte créé ! 50 TC offerts.')
    } else {
      await store.login(form.email, form.password)
      store.showToast('Connexion réussie')
    }
    router.push('/mon-espace')
  } catch (e) { errors.value = [e.message] }
}
const title = computed(() => (mode.value === 'register' ? 'Créer ton compte' : 'Bon retour !'))
</script>

<template>
  <section class="container auth">
    <div class="tabs" role="tablist">
      <button :class="{ active: mode === 'register' }" @click="mode = 'register'; errors = []">S’inscrire</button>
      <button :class="{ active: mode === 'login' }" @click="mode = 'login'; errors = []">Se connecter</button>
    </div>
    <form class="card pad" @submit.prevent="submit" novalidate>
      <h1>{{ title }}</h1>
      <ul v-if="errors.length" class="error-list"><li v-for="e in errors" :key="e">{{ e }}</li></ul>

      <div v-if="mode === 'register'" class="form-row">
        <div class="form-group"><label for="fn">Prénom</label><input id="fn" class="form-input" v-model="form.firstName" autocomplete="given-name"></div>
        <div class="form-group"><label for="ln">Nom</label><input id="ln" class="form-input" v-model="form.lastName" autocomplete="family-name"></div>
      </div>
      <div class="form-group"><label for="em">Adresse mail étudiante</label><input id="em" type="email" class="form-input" v-model="form.email" autocomplete="email"></div>
      <div v-if="mode === 'register'" class="form-group"><label for="ag">Âge</label><input id="ag" type="number" class="form-input" v-model.number="form.age" min="16" max="35"></div>
      <div class="form-group"><label for="pw">Mot de passe</label><input id="pw" type="password" class="form-input" v-model="form.password" autocomplete="current-password"></div>

      <template v-if="mode === 'register'">
        <fieldset class="form-group">
          <legend>Centres d’intérêt</legend>
          <div class="pills">
            <button type="button" v-for="i in interestsList" :key="i" class="pill" :class="{ active: form.interests.includes(i) }" @click="toggle(i)">{{ i }}</button>
          </div>
        </fieldset>
        <div class="form-group"><label for="av">Disponibilités (optionnel)</label><input id="av" class="form-input" v-model="form.availability" placeholder="Week-ends, mercredi après-midi…"></div>
        <p class="bonus">🪙 Tu recevras 50 TROK-coins à la création de ton compte.</p>
      </template>
      <button class="btn btn-green btn-lg full">{{ mode === 'register' ? 'Créer mon compte' : 'Se connecter' }}</button>
    </form>
  </section>
</template>
