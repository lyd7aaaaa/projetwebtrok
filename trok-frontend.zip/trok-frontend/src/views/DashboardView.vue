<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { api } from '../api'
import { store } from '../store'

const router = useRouter()
const tab = ref('overview')
const myCourses = ref([])
const transactions = ref([])

onMounted(async () => {
  try {
    myCourses.value = (await api.get('/courses/mine')).courses
    transactions.value = (await api.get('/transactions')).transactions
  } catch (e) { store.showToast('⚠️ ' + e.message) }
})

async function remove(c) {
  if (!confirm('Supprimer ce cours ?')) return
  await api.del('/courses/' + c.id)
  myCourses.value = myCourses.value.filter(x => x.id !== c.id)
  store.showToast('Cours supprimé')
}
async function saveProfile() {
  try {
    const u = store.user
    store.user = (await api.put('/auth/me', { firstName: u.firstName, lastName: u.lastName, age: u.age, interests: u.interests, availability: u.availability })).user
    store.showToast('Profil sauvegardé')
  } catch (e) { store.showToast('⚠️ ' + e.message) }
}
const fmt = (d) => new Date(d).toLocaleDateString('fr-FR')
</script>

<template>
  <div class="container section dash">
    <aside>
      <div class="card pad center">
        <div class="avatar">{{ store.user.firstName[0] }}{{ store.user.lastName[0] }}</div>
        <h3>{{ store.user.firstName }} {{ store.user.lastName }}</h3>
        <p class="muted small">{{ store.user.email }}</p>
        <p class="balance">{{ store.user.balance }} TC</p>
      </div>
      <nav class="side-nav" aria-label="Mon espace">
        <button :class="{ active: tab === 'overview' }" @click="tab = 'overview'">📊 Vue d’ensemble</button>
        <button :class="{ active: tab === 'courses' }" @click="tab = 'courses'">📚 Mes cours</button>
        <button :class="{ active: tab === 'tx' }" @click="tab = 'tx'">💱 Transactions</button>
        <button :class="{ active: tab === 'profile' }" @click="tab = 'profile'">👤 Mon profil</button>
      </nav>
    </aside>

    <section>
      <div v-if="tab === 'overview'">
        <h1>Vue d’ensemble</h1>
        <div class="grid-3">
          <div class="card pad"><p class="muted small">Solde</p><p class="big">{{ store.user.balance }}</p></div>
          <div class="card pad"><p class="muted small">Cours proposés</p><p class="big">{{ myCourses.length }}</p></div>
          <div class="card pad"><p class="muted small">Transactions</p><p class="big">{{ transactions.length }}</p></div>
        </div>
      </div>

      <div v-else-if="tab === 'courses'">
        <div class="row-between"><h1>Mes cours</h1><router-link to="/publier" class="btn btn-green btn-sm">+ Nouveau cours</router-link></div>
        <p v-if="!myCourses.length" class="muted">Tu n’as pas encore proposé de cours.</p>
        <div v-for="c in myCourses" :key="c.id" class="card pad row-between item">
          <div><strong>{{ c.emoji }} {{ c.title }}</strong><p class="muted small">{{ c.level }} · {{ c.price }} TC</p></div>
          <div class="actions">
            <button class="btn btn-outline btn-sm" @click="router.push('/publier/' + c.id)">Modifier</button>
            <button class="btn btn-danger btn-sm" @click="remove(c)">Supprimer</button>
          </div>
        </div>
      </div>

      <div v-else-if="tab === 'tx'">
        <h1>Transactions</h1>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Date</th><th>Cours</th><th>Type</th><th>Montant</th></tr></thead>
            <tbody>
              <tr v-for="t in transactions" :key="t.id">
                <td>{{ fmt(t.createdAt) }}</td>
                <td>{{ t.course?.title || 'Bonus inscription' }}</td>
                <td>{{ t.buyerId === store.user.id ? 'Achat' : 'Vente' }}</td>
                <td :class="t.buyerId === store.user.id ? 'neg' : 'pos'">{{ t.buyerId === store.user.id ? '−' : '+' }}{{ t.amount }} TC</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <form v-else class="card pad" @submit.prevent="saveProfile">
        <h1>Mon profil</h1>
        <div class="form-row">
          <div class="form-group"><label for="pf">Prénom</label><input id="pf" class="form-input" v-model="store.user.firstName"></div>
          <div class="form-group"><label for="pl">Nom</label><input id="pl" class="form-input" v-model="store.user.lastName"></div>
        </div>
        <div class="form-group"><label for="pa">Âge</label><input id="pa" type="number" class="form-input" v-model.number="store.user.age"></div>
        <div class="form-group"><label for="pe">Email</label><input id="pe" class="form-input" :value="store.user.email" disabled></div>
        <div class="form-group"><label for="pd">Disponibilités</label><input id="pd" class="form-input" v-model="store.user.availability"></div>
        <button class="btn btn-green">Sauvegarder</button>
      </form>
    </section>
  </div>
</template>
