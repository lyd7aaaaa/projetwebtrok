<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { api } from '../api'
import { store } from '../store'

const route = useRoute()
const router = useRouter()
const editId = route.params.id          // présent => mode modification (UPDATE), sinon création (CREATE)
const errors = ref([])
const emojis = { Code: '💻', Musique: '🎵', Art: '🎨', Langues: '🌍', Maths: '📐', Sport: '🏃', Photo: '📸', Cuisine: '🍳' }
const form = reactive({ title: '', category: '', description: '', level: '', price: '', inPerson: false, remote: true })

onMounted(async () => {
  if (!editId) return
  try { Object.assign(form, (await api.get('/courses/' + editId)).course) }
  catch (e) { errors.value = [e.message] }
})

const emoji = computed(() => emojis[form.category] || '📚')

function validate() {
  const e = []
  if (form.title.trim().length < 5) e.push('Titre : 5 caractères minimum.')
  if (!form.category) e.push('Choisis un domaine.')
  if (form.description.trim().length < 80) e.push('Description : 80 caractères minimum.')
  if (!form.level) e.push('Choisis un niveau.')
  if (!(form.price >= 5 && form.price <= 200)) e.push('Prix entre 5 et 200 TC.')
  if (!form.inPerson && !form.remote) e.push('Choisis au moins une modalité.')
  return e
}
async function submit() {
  errors.value = validate()
  if (errors.value.length) return
  const payload = { ...form, emoji: emoji.value, price: Number(form.price) }
  try {
    if (editId) await api.put('/courses/' + editId, payload)
    else await api.post('/courses', payload)
    store.showToast(editId ? 'Cours modifié' : 'Cours publié')
    router.push('/cours')
  } catch (e) { errors.value = [e.message] }
}
</script>

<template>
  <div class="container section publish">
    <form class="card pad" @submit.prevent="submit" novalidate>
      <h1>{{ editId ? 'Modifier mon cours' : 'Proposer un cours' }}</h1>
      <ul v-if="errors.length" class="error-list"><li v-for="e in errors" :key="e">{{ e }}</li></ul>
      <div class="form-group"><label for="t">Titre du cours</label><input id="t" class="form-input" v-model.trim="form.title"></div>
      <div class="form-group"><label for="c">Domaine</label>
        <select id="c" class="form-input" v-model="form.category">
          <option value="">Choisir un domaine…</option>
          <option v-for="(e, name) in emojis" :key="name" :value="name">{{ e }} {{ name }}</option>
        </select>
      </div>
      <div class="form-group"><label for="d">Description</label><textarea id="d" class="form-input" rows="5" v-model="form.description"></textarea>
        <small class="muted">{{ form.description.length }} / 80 caractères minimum</small></div>
      <div class="form-group"><label>Niveau</label>
        <div class="pills"><button type="button" v-for="l in ['Débutant', 'Intermédiaire', 'Avancé']" :key="l" class="pill" :class="{ active: form.level === l }" @click="form.level = l">{{ l }}</button></div>
      </div>
      <div class="form-group"><label for="p">Prix (TC)</label><input id="p" type="number" min="5" max="200" class="form-input" v-model="form.price"></div>
      <label class="check"><input type="checkbox" v-model="form.inPerson"> 📍 Présentiel possible</label>
      <label class="check"><input type="checkbox" v-model="form.remote"> 💻 Distanciel possible</label>
      <button class="btn btn-green btn-lg full">{{ editId ? 'Enregistrer' : 'Publier mon cours' }}</button>
    </form>

    <!-- Aperçu en direct : liaison de données réactive -->
    <aside class="card pad preview">
      <p class="muted small">Aperçu de ta fiche</p>
      <div class="thumb">{{ emoji }}</div>
      <h3 :class="{ muted: !form.title }">{{ form.title || 'Titre de ton cours' }}</h3>
      <p class="muted">{{ form.description || 'Ta description apparaîtra ici…' }}</p>
      <p class="price">{{ form.price || '—' }} TC</p>
      <p class="small muted">{{ form.level || 'Niveau —' }} · {{ form.inPerson ? '📍 Présentiel' : '💻 Distanciel' }}</p>
    </aside>
  </div>
</template>
