import { createRouter, createWebHistory } from 'vue-router'
import { store } from './store'

const routes = [
  { path: '/', component: () => import('./views/HomeView.vue') },
  { path: '/cours', component: () => import('./views/CoursesView.vue') },
  { path: '/connexion', component: () => import('./views/AuthView.vue') },
  { path: '/publier', component: () => import('./views/PublishView.vue'), meta: { auth: true } },
  { path: '/publier/:id', component: () => import('./views/PublishView.vue'), meta: { auth: true } },
  { path: '/messages', component: () => import('./views/MessagesView.vue'), meta: { auth: true } },
  { path: '/mon-espace', component: () => import('./views/DashboardView.vue'), meta: { auth: true } }
]

const router = createRouter({ history: createWebHistory(), routes, scrollBehavior: () => ({ top: 0 }) })

// Garde de navigation : routes protégées (autorisation côté client, le serveur re-vérifie toujours)
router.beforeEach((to) => {
  if (to.meta.auth && !store.user) return '/connexion'
})
export default router
