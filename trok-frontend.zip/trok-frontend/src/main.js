import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { store } from './store'
import './style.css'

// On récupère la session (cookie) avant de monter l'application
store.fetchMe().finally(() => createApp(App).use(router).mount('#app'))
