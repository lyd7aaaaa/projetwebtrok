<script setup>
// Composant réutilisable : reçoit un cours en prop, émet "open" au clic
defineProps({ course: { type: Object, required: true } })
defineEmits(['open'])
const lv = { 'Débutant': 'beg', 'Intermédiaire': 'int', 'Avancé': 'adv' }
</script>

<template>
  <article class="card course" tabindex="0" @click="$emit('open', course)" @keyup.enter="$emit('open', course)">
    <div class="thumb">{{ course.emoji }}</div>
    <div class="card-body">
      <span class="tag">{{ course.category }}</span>
      <h3>{{ course.title }}</h3>
      <p class="muted">{{ course.description.slice(0, 90) }}…</p>
      <p class="muted small">{{ course.teacher?.firstName }} {{ course.teacher?.lastName }}</p>
      <div class="card-foot">
        <span class="small"><i class="dot" :class="'lv-' + lv[course.level]"></i>{{ course.level }}</span>
        <span class="price">{{ course.price }} TC</span>
      </div>
    </div>
  </article>
</template>
