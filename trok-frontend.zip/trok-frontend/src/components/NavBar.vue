<script setup>
import { useRouter } from 'vue-router'
import { store } from '../store'
const router = useRouter()
async function logout() {
  await store.logout()
  store.showToast('Déconnecté')
  router.push('/')
}
</script>

<template>
  <header class="nav">
    <router-link to="/" class="nav-logo">TR<span>●</span>K</router-link>
    <nav class="nav-links" aria-label="Navigation principale">
      <router-link to="/">Accueil</router-link>
      <router-link to="/cours">Cours disponibles</router-link>
      <router-link to="/publier">Proposer un cours</router-link>
      <router-link to="/messages">Messagerie</router-link>
      <router-link to="/mon-espace">Mon espace</router-link>
    </nav>
    <div class="nav-right">
      <!-- Rendu conditionnel : connecté ou non -->
      <template v-if="store.user">
        <span class="wallet" title="Ton solde">🪙 {{ store.user.balance }} TC</span>
        <button class="btn btn-outline btn-sm" @click="logout">Déconnexion</button>
      </template>
      <router-link v-else to="/connexion" class="btn btn-green btn-sm">Connexion</router-link>
    </div>
  </header>
</template>
