<script setup>
import { store } from '../store'
defineProps({ course: { type: Object, required: true } })
defineEmits(['close', 'buy', 'edit', 'delete', 'contact'])
</script>

<template>
  <div class="overlay" @click.self="$emit('close')">
    <div class="modal" role="dialog" aria-modal="true">
      <button class="modal-close" aria-label="Fermer" @click="$emit('close')">✕</button>
      <h2>{{ course.emoji }} {{ course.title }}</h2>
      <p class="muted">Par {{ course.teacher?.firstName }} {{ course.teacher?.lastName }} · {{ course.category }}</p>
      <p class="desc">{{ course.description }}</p>
      <ul class="details">
        <li><b>Niveau</b> {{ course.level }}</li>
        <li><b>Prix</b> {{ course.price }} TC</li>
        <li><b>Présentiel</b> {{ course.inPerson ? 'Oui' : 'Non' }}</li>
        <li><b>Distanciel</b> {{ course.remote ? 'Oui' : 'Non' }}</li>
      </ul>
      <!-- Le propriétaire gère son cours, les autres l'achètent -->
      <div class="actions" v-if="store.user && store.user.id === course.teacherId">
        <button class="btn btn-outline" @click="$emit('edit', course)">Modifier</button>
        <button class="btn btn-danger" @click="$emit('delete', course)">Supprimer</button>
      </div>
      <div class="actions" v-else>
        <button class="btn btn-outline" @click="$emit('contact', course)">Contacter</button>
        <button class="btn btn-gold" @click="$emit('buy', course)">Acheter pour {{ course.price }} TC</button>
      </div>
    </div>
  </div>
</template>
